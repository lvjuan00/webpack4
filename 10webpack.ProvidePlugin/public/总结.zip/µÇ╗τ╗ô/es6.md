## let const

- let、const 都是块级作用域，声明的变量不可以重复声明

- let 声明的变量可以改变

- const 声明的是常量，不能变

- var 是函数作用域

## 变量的解构赋值


## Class


##  Promise


##箭头函数

如果加{}需要手写return值，否则执行的结果就是return值
