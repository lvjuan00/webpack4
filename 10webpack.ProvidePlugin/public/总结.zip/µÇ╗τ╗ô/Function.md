## 函数的声明

- 字面量: ```function fn() {}```

- 表达式: ```var print = function(s) {}```

注意：变量名提升


## 作用域

作用域（scope）指的是变量存在的范围

- 全局作用域: window下的属性

- 局部作用域

在ES5规范中只有函数作用域：一个function就是一个作用域

在ES6中新添加了块级作用域


``` javascript
// 全局作用
var a = 1

function fn() {
    // 局部作用域
    var b = 2

    function fn2() {
        // 局部作用域
        var c = 3
    }
}


```

## 闭包

``` javascript

function f1() {
  var n = 999

  return function () {
    return n
  }
}

var result = f1()
result() // 999

```





